<?php
include 'index.php';
var_dump(checkYahoo('sara123@yahoo.com'));